<div className="navbar" style="position:absolute; left:0px; height:200px; background-color:yellow; display:block;">
    <a href="#home">Home</a>
    <a href="#news">News</a>
    <div class="dropdown">
        <button class="dropdownButton">Dropdown</button>
    </div>
</div>