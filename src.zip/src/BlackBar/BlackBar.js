const BlackBar = () => {
  return <div>Black Bar</div>;
};

export default BlackBar;
